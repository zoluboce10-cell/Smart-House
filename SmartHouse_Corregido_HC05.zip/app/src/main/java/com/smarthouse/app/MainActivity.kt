package com.smarthouse.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {

    // UUID estándar para el perfil SPP (Serial Port Profile) de Bluetooth Classic
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null
    private var isConnected: Boolean = false

    private val pairedDevicesList = ArrayList<BluetoothDevice>()
    private val deviceNamesList = ArrayList<String>()
    private var selectedDevice: BluetoothDevice? = null

    // Vistas de la interfaz
    private lateinit var tvStatus: TextView
    private lateinit var tvLastAction: TextView
    private lateinit var spinnerDevices: Spinner
    private lateinit var btnConnect: Button
    private lateinit var progressBar: ProgressBar

    // Botones de Iluminación
    private lateinit var btnSalaOn: Button
    private lateinit var btnSalaOff: Button
    private lateinit var btnCocinaOn: Button
    private lateinit var btnCocinaOff: Button
    private lateinit var btnHabOn: Button
    private lateinit var btnHabOff: Button
    private lateinit var btnExtOn: Button
    private lateinit var btnExtOff: Button

    // Botones de Puerta y Cortina
    private lateinit var btnPuertaAbrir: Button
    private lateinit var btnPuertaCerrar: Button
    private lateinit var btnCortinaAbrir: Button
    private lateinit var btnCortinaCerrar: Button

    private val mainHandler = Handler(Looper.getMainLooper())

    // Solicitud de permisos en tiempo de ejecución (Android 12+)
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            loadPairedDevices()
        } else {
            Toast.makeText(this, "Se requieren permisos Bluetooth para conectar al HC-05", Toast.LENGTH_LONG).show()
            updateStatusText(false, "Permisos Bluetooth denegados")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        initBluetooth()
        setupListeners()
    }

    private fun initViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvLastAction = findViewById(R.id.tvLastAction)
        spinnerDevices = findViewById(R.id.spinnerDevices)
        btnConnect = findViewById(R.id.btnConnect)
        progressBar = findViewById(R.id.progressBar)

        // Iluminación
        btnSalaOn = findViewById(R.id.btnSalaOn)
        btnSalaOff = findViewById(R.id.btnSalaOff)
        btnCocinaOn = findViewById(R.id.btnCocinaOn)
        btnCocinaOff = findViewById(R.id.btnCocinaOff)
        btnHabOn = findViewById(R.id.btnHabOn)
        btnHabOff = findViewById(R.id.btnHabOff)
        btnExtOn = findViewById(R.id.btnExtOn)
        btnExtOff = findViewById(R.id.btnExtOff)

        // Puerta y Cortinas
        btnPuertaAbrir = findViewById(R.id.btnPuertaAbrir)
        btnPuertaCerrar = findViewById(R.id.btnPuertaCerrar)
        btnCortinaAbrir = findViewById(R.id.btnCortinaAbrir)
        btnCortinaCerrar = findViewById(R.id.btnCortinaCerrar)

        updateStatusText(false)
    }

    private fun initBluetooth() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Este dispositivo no soporta Bluetooth", Toast.LENGTH_LONG).show()
            tvStatus.text = "🔴 Bluetooth no disponible"
            btnConnect.isEnabled = false
            return
        }

        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadPairedDevices()
        }
    }

    @SuppressLint("MissingPermission")
    private fun loadPairedDevices() {
        pairedDevicesList.clear()
        deviceNamesList.clear()

        val paired = bluetoothAdapter?.bondedDevices
        var hc05Index = -1

        if (paired != null && paired.isNotEmpty()) {
            var index = 0
            for (device in paired) {
                pairedDevicesList.add(device)
                val displayName = "${device.name ?: "Desconocido"} (${device.address})"
                deviceNamesList.add(displayName)

                // Detectar si es el HC-05 para preseleccionarlo automáticamente
                if (device.name != null && device.name.contains("HC-05", ignoreCase = true)) {
                    hc05Index = index
                }
                index++
            }
        } else {
            deviceNamesList.add("No hay dispositivos vinculados")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, deviceNamesList)
        spinnerDevices.adapter = adapter

        if (hc05Index != -1) {
            spinnerDevices.setSelection(hc05Index)
            selectedDevice = pairedDevicesList[hc05Index]
        } else if (pairedDevicesList.isNotEmpty()) {
            selectedDevice = pairedDevicesList[0]
        }

        spinnerDevices.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position < pairedDevicesList.size) {
                    selectedDevice = pairedDevicesList[position]
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupListeners() {
        btnConnect.setOnClickListener {
            if (isConnected) {
                disconnectBluetooth()
            } else {
                connectToSelectedDevice()
            }
        }

        // Iluminación
        btnSalaOn.setOnClickListener { sendCommand("SALA_ON", "Sala encendida") }
        btnSalaOff.setOnClickListener { sendCommand("SALA_OFF", "Sala apagada") }
        btnCocinaOn.setOnClickListener { sendCommand("COCINA_ON", "Cocina encendida") }
        btnCocinaOff.setOnClickListener { sendCommand("COCINA_OFF", "Cocina apagada") }
        btnHabOn.setOnClickListener { sendCommand("HAB_ON", "Habitación encendida") }
        btnHabOff.setOnClickListener { sendCommand("HAB_OFF", "Habitación apagada") }
        btnExtOn.setOnClickListener { sendCommand("EXT_ON", "Exterior encendido") }
        btnExtOff.setOnClickListener { sendCommand("EXT_OFF", "Exterior apagado") }

        // Puerta
        btnPuertaAbrir.setOnClickListener { sendCommand("PUERTA_ABRIR", "Puerta abierta") }
        btnPuertaCerrar.setOnClickListener { sendCommand("PUERTA_CERRAR", "Puerta cerrada") }

        // Cortinas
        btnCortinaAbrir.setOnClickListener { sendCommand("CORTINA_ABRIR", "Cortinas abiertas") }
        btnCortinaCerrar.setOnClickListener { sendCommand("CORTINA_CERRAR", "Cortinas cerradas") }
    }

    @SuppressLint("MissingPermission")
    private fun connectToSelectedDevice() {
        if (selectedDevice == null) {
            Toast.makeText(this, "Selecciona primero el dispositivo HC-05", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        btnConnect.isEnabled = false
        tvStatus.text = "🟡 Conectando a ${selectedDevice?.name ?: "HC-05"}..."

        // Conectar en un hilo secundario para no bloquear la interfaz gráfica (UI Thread)
        Thread {
            try {
                // Cancelar cualquier proceso de búsqueda activa para mayor estabilidad
                bluetoothAdapter?.cancelDiscovery()

                // Crear socket RFCOMM usando el UUID SPP estándar
                bluetoothSocket = selectedDevice!!.createRfcommSocketToServiceRecord(SPP_UUID)
                bluetoothSocket?.connect()

                outputStream = bluetoothSocket?.outputStream
                inputStream = bluetoothSocket?.inputStream
                isConnected = true

                mainHandler.post {
                    progressBar.visibility = View.GONE
                    btnConnect.isEnabled = true
                    btnConnect.text = "Desconectar"
                    updateStatusText(true)
                    Toast.makeText(this@MainActivity, "Conectado exitosamente a HC-05", Toast.LENGTH_SHORT).show()
                }

                // Iniciar hilo de lectura para confirmaciones del Arduino
                startListeningForArduinoResponses()

            } catch (e: IOException) {
                e.printStackTrace()
                disconnectBluetooth()
                mainHandler.post {
                    progressBar.visibility = View.GONE
                    btnConnect.isEnabled = true
                    updateStatusText(false, "Fallo al conectar: ${e.localizedMessage}")
                    Toast.makeText(this@MainActivity, "No se pudo conectar al HC-05. Verifica que esté encendido y emparejado.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun disconnectBluetooth() {
        isConnected = false
        try {
            outputStream?.close()
            inputStream?.close()
            bluetoothSocket?.close()
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            outputStream = null
            inputStream = null
            bluetoothSocket = null
            mainHandler.post {
                btnConnect.text = "Conectar"
                updateStatusText(false)
            }
        }
    }

    /**
     * Envía exactamente el comando indicado seguido de un salto de línea (\n) al Arduino
     */
    private fun sendCommand(cmd: String, actionDescription: String) {
        if (!isConnected || outputStream == null) {
            Toast.makeText(this, "Conecta primero el HC-05 para enviar comandos", Toast.LENGTH_SHORT).show()
            tvLastAction.text = "Última acción: Intento fallido (No conectado)"
            return
        }

        Thread {
            try {
                // El comando DEBE terminar con \n según la especificación
                val message = cmd + "\n"
                outputStream?.write(message.toByteArray(Charsets.UTF_8))
                outputStream?.flush()

                mainHandler.post {
                    tvLastAction.text = "Última acción: $actionDescription ($cmd)"
                }
            } catch (e: IOException) {
                e.printStackTrace()
                mainHandler.post {
                    Toast.makeText(this@MainActivity, "Error al enviar comando: ${e.message}", Toast.LENGTH_SHORT).show()
                    tvLastAction.text = "Última acción: Error de transmisión ($cmd)"
                    disconnectBluetooth()
                }
            }
        }.start()
    }

    private fun startListeningForArduinoResponses() {
        Thread {
            val buffer = ByteArray(1024)
            while (isConnected) {
                try {
                    val bytesRead = inputStream?.read(buffer) ?: -1
                    if (bytesRead > 0) {
                        val response = String(buffer, 0, bytesRead).trim()
                        mainHandler.post {
                            // Si el Arduino devuelve confirmación, se puede registrar
                            if (response.isNotEmpty()) {
                                // Confirmación recibida del Arduino
                            }
                        }
                    }
                } catch (e: IOException) {
                    break
                }
            }
        }.start()
    }

    private fun updateStatusText(connected: Boolean, customMessage: String? = null) {
        if (connected) {
            tvStatus.text = "🔵 Conectado"
            tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_blue_dark))
        } else {
            tvStatus.text = customMessage ?: "🔴 Desconectado"
            tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectBluetooth()
    }
}
