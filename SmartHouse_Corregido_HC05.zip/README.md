# Smart House - proyecto corregido

Este ZIP conserva la aplicación Android generada por Google AI Studio y corrige el sketch de Arduino para que coincida con el montaje físico ya probado.

## Pines actuales
- Sala LED: D2
- Cocina LED: D3
- Habitación LED: D4
- Exterior LED: D5
- Servo puerta: D6
- Servo cortina: D7
- HC-05 TXD -> D10
- HC-05 RXD -> D11 (con divisor de tensión recomendado)
- HC-05: 9600 baudios

## Importante
No usar el sketch original de AI Studio que asignaba actuadores a D4-D9. Este ZIP ya contiene el sketch corregido.

Los comandos Bluetooth son: SALA_ON/OFF, COCINA_ON/OFF, HAB_ON/OFF, EXT_ON/OFF, PUERTA_ABRIR/CERRAR y CORTINA_ABRIR/CERRAR.
