/*
 * SMART HOUSE - Arduino Uno + HC-05
 * Pines VERIFICADOS con el montaje actual del proyecto.
 *
 * LEDs:
 *   Sala       -> D2 (resistencia 220 ohm -> LED -> GND)
 *   Cocina     -> D3
 *   Habitacion -> D4
 *   Exterior   -> D5
 *
 * Servos:
 *   Puerta     -> D6
 *   Cortina    -> D7
 *
 * HC-05:
 *   TXD -> Arduino D10 (RX de SoftwareSerial)
 *   RXD -> Arduino D11 (TX de SoftwareSerial; usar divisor de tension)
 *   VCC -> 5V
 *   GND -> GND
 *
 * Bluetooth: 9600 baudios, Bluetooth Classic SPP.
 */

#include <Servo.h>
#include <SoftwareSerial.h>

const int LED_SALA = 2;
const int LED_COCINA = 3;
const int LED_HABITACION = 4;
const int LED_EXTERIOR = 5;

const int SERVO_PUERTA = 6;
const int SERVO_CORTINA = 7;

Servo puerta;
Servo cortina;
SoftwareSerial bluetooth(10, 11); // RX, TX

void procesarComando(String comando) {
  comando.trim();

  if (comando == "SALA_ON") {
    digitalWrite(LED_SALA, HIGH);
    bluetooth.println("OK: SALA_ENCENDIDA");
  } else if (comando == "SALA_OFF") {
    digitalWrite(LED_SALA, LOW);
    bluetooth.println("OK: SALA_APAGADA");
  } else if (comando == "COCINA_ON") {
    digitalWrite(LED_COCINA, HIGH);
    bluetooth.println("OK: COCINA_ENCENDIDA");
  } else if (comando == "COCINA_OFF") {
    digitalWrite(LED_COCINA, LOW);
    bluetooth.println("OK: COCINA_APAGADA");
  } else if (comando == "HAB_ON") {
    digitalWrite(LED_HABITACION, HIGH);
    bluetooth.println("OK: HAB_ENCENDIDA");
  } else if (comando == "HAB_OFF") {
    digitalWrite(LED_HABITACION, LOW);
    bluetooth.println("OK: HAB_APAGADA");
  } else if (comando == "EXT_ON") {
    digitalWrite(LED_EXTERIOR, HIGH);
    bluetooth.println("OK: EXT_ENCENDIDO");
  } else if (comando == "EXT_OFF") {
    digitalWrite(LED_EXTERIOR, LOW);
    bluetooth.println("OK: EXT_APAGADO");
  } else if (comando == "PUERTA_ABRIR") {
    puerta.write(90);
    bluetooth.println("OK: PUERTA_ABIERTA");
  } else if (comando == "PUERTA_CERRAR") {
    puerta.write(0);
    bluetooth.println("OK: PUERTA_CERRADA");
  } else if (comando == "CORTINA_ABRIR") {
    cortina.write(90);
    bluetooth.println("OK: CORTINA_ABIERTA");
  } else if (comando == "CORTINA_CERRAR") {
    cortina.write(0);
    bluetooth.println("OK: CORTINA_CERRADA");
  } else {
    bluetooth.println("ERROR: COMANDO_DESCONOCIDO");
  }
}

void setup() {
  pinMode(LED_SALA, OUTPUT);
  pinMode(LED_COCINA, OUTPUT);
  pinMode(LED_HABITACION, OUTPUT);
  pinMode(LED_EXTERIOR, OUTPUT);

  puerta.attach(SERVO_PUERTA);
  cortina.attach(SERVO_CORTINA);

  puerta.write(0);
  cortina.write(0);

  bluetooth.begin(9600);
}

void loop() {
  if (bluetooth.available()) {
    String comando = bluetooth.readStringUntil('\n');
    procesarComando(comando);
  }
}
